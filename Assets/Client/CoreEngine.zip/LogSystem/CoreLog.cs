public static class CoreLog
{
    static CoreLog()
    {
        Init();
    }

    private static void Init()
    {
        
    }
}